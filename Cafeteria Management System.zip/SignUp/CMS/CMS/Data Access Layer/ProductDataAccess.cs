﻿using CMS.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMS.Data_Access_Layer
{
    class ProductDataAccess:DataAccess
    {
        public List<Product> GetProducts()
        {
            string sql = "SELECT * FROM Products";
            SqlDataReader reader = this.GetData(sql);
            List<Product> products = new List<Product>();

            while (reader.Read())
            {
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                products.Add(product);
            }

            return products;
        }

        public List<Product> GetProductListByNames(string str)
        {
            string sql = "SELECT * FROM Products WHERE ProductName LIKE '" + str + "%'";
            SqlDataReader reader = this.GetData(sql);
            List<Product> products = new List<Product>();

            while (reader.Read())
            {
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                products.Add(product);
            }

            return products;
        }
    }
}
