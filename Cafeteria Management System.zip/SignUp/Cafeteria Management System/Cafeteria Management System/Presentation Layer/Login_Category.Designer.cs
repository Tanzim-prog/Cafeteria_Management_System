﻿
namespace Cafeteria_Management_System.Presentation_Layer
{
    partial class Login_Category
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.welcomeButton = new System.Windows.Forms.Button();
            this.cashierButton = new System.Windows.Forms.Button();
            this.managerButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.exitButton);
            this.groupBox1.Controls.Add(this.welcomeButton);
            this.groupBox1.Controls.Add(this.cashierButton);
            this.groupBox1.Controls.Add(this.managerButton);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(47, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(399, 277);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Category";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(324, 9);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // welcomeButton
            // 
            this.welcomeButton.Location = new System.Drawing.Point(232, 9);
            this.welcomeButton.Name = "welcomeButton";
            this.welcomeButton.Size = new System.Drawing.Size(86, 23);
            this.welcomeButton.TabIndex = 2;
            this.welcomeButton.Text = "Welcome";
            this.welcomeButton.UseVisualStyleBackColor = true;
            this.welcomeButton.Click += new System.EventHandler(this.welcomeButton_Click);
            // 
            // cashierButton
            // 
            this.cashierButton.Location = new System.Drawing.Point(232, 113);
            this.cashierButton.Name = "cashierButton";
            this.cashierButton.Size = new System.Drawing.Size(124, 64);
            this.cashierButton.TabIndex = 1;
            this.cashierButton.Text = "Cashier";
            this.cashierButton.UseVisualStyleBackColor = true;
            this.cashierButton.Click += new System.EventHandler(this.cashierButton_Click);
            // 
            // managerButton
            // 
            this.managerButton.Location = new System.Drawing.Point(41, 113);
            this.managerButton.Name = "managerButton";
            this.managerButton.Size = new System.Drawing.Size(124, 64);
            this.managerButton.TabIndex = 0;
            this.managerButton.Text = "Manager";
            this.managerButton.UseVisualStyleBackColor = true;
            this.managerButton.Click += new System.EventHandler(this.managerButton_Click);
            // 
            // Login_Category
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 358);
            this.Controls.Add(this.groupBox1);
            this.Name = "Login_Category";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login_Category";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_Category_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button welcomeButton;
        private System.Windows.Forms.Button cashierButton;
        private System.Windows.Forms.Button managerButton;
    }
}