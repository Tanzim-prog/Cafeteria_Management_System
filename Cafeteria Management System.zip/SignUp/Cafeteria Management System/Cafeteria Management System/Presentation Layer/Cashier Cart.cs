﻿using Cafeteria_Management_System.Data_Access_Layer;
using Cafeteria_Management_System.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Cashier_Cart : Form
    {
        public Cashier_Cart()
        {
            InitializeComponent();
        }

        private void Cashier_Cart_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void dashboardButton_Click(object sender, EventArgs e)
        {
            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();
        }

        private void Cashier_Cart_Load(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            searchboxDataGridView.DataSource = productDataAccess.GetProducts();
        }

        private void searchproductnameTextBox_TextChanged(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            searchboxDataGridView.DataSource = productDataAccess.GetProductListByNames(searchproductnameTextBox.Text);
        }

        void UpdateGridView()
        {
            SellDataAccess sellDataAccess = new SellDataAccess();
            cartDataGridView.DataSource = sellDataAccess.GetSells();
        }

        void ClearFields()
        {
            cartproductnameTextBox.Text = string.Empty;
            cartordernoTextBox.Text = string.Empty;
            cartproductpriceTextBox.Text = string.Empty;
            cartproductquantityTextBox.Text = string.Empty;
            carttotalTextBox.Text = string.Empty;
            updateproductnameTextBox.Text = string.Empty;
            updateproductquantityTextBox.Text = string.Empty;
            deleteordernoTextBox.Text = string.Empty;
            cartproductnameTextBox.Text = string.Empty;
            cartproductpriceTextBox.Text = string.Empty;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (cartordernoTextBox.Text == "")
            {
                MessageBox.Show("Order No can not be empty");
            }
            else if (cartproductnameTextBox.Text == "")
            {
                MessageBox.Show("Product Name can not be empty");
            }
            else if (cartproductpriceTextBox.Text == "")
            {
                MessageBox.Show("Product Price can not be empty");
            }
            else if (cartproductquantityTextBox.Text == "")
            {
                MessageBox.Show("Product Quantity can not be empty");
            }
            else if (carttotalTextBox.Text == "")
            {
                MessageBox.Show("Cart Total can not be empty");
            }
            else
            {
                SellDataAccess sellDataAccess = new SellDataAccess();
                if (sellDataAccess.CreateSell(Convert.ToInt32(cartordernoTextBox.Text), cartproductnameTextBox.Text, Convert.ToDouble(cartproductpriceTextBox.Text), Convert.ToInt32(cartproductquantityTextBox.Text), Convert.ToDouble(carttotalTextBox.Text)))
                {
                    MessageBox.Show("Added to Cart");
                    UpdateGridView();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to add");
                    ClearFields();
                }
            }
        }

        private void cartproductnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void cartproductidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void cartproductpriceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void cartproductquantityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void carttotalTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void searchproductnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }

        //private void cartproductnameTextBox_Leave(object sender, EventArgs e)
        //{
        //    if (cartproductnameTextBox.Text != "")
        //    {
        //        errorProvider1.Clear();
        //    }
        //    else
        //    {
        //        errorProvider1.SetError(this.cartproductnameTextBox, "Can not be empty");
        //        return;
        //    }
        //}

        //private void cartproductidTextBox_Leave(object sender, EventArgs e)
        //{
        //    if (cartordernoTextBox.Text != "")
        //    {
        //        errorProvider2.Clear();
        //    }
        //    else
        //    {
        //        errorProvider2.SetError(this.cartordernoTextBox, "Can not be empty");
        //        return;
        //    }
        //}
        //private void cartproductpriceTextBox_Leave(object sender, EventArgs e)
        //{
        //    if (cartproductpriceTextBox.Text != "")
        //    {
        //        errorProvider3.Clear();
        //    }
        //    else
        //    {
        //        errorProvider3.SetError(this.cartproductpriceTextBox, "Can not be empty");
        //        return;
        //    }
        //}
        //private void cartproductquantityTextBox_Leave(object sender, EventArgs e)
        //{
        //    if (cartproductquantityTextBox.Text != "")
        //    {
        //        errorProvider4.Clear();
        //    }
        //    else
        //    {
        //        errorProvider4.SetError(this.cartproductquantityTextBox, "Can not be empty");
        //        return;
        //    }
        //}
        //private void carttotalTextBox_Leave(object sender, EventArgs e)
        //{
        //    if (carttotalTextBox.Text != "")
        //    {
        //        errorProvider5.Clear();
        //    }
        //    else
        //    {
        //        errorProvider5.SetError(this.carttotalTextBox, "Can not be empty");
        //        return;
        //    }
        //}

        private void deleteButton_Click(object sender, EventArgs e)
        {
            SellDataAccess sellDataAccess = new SellDataAccess();
            //int no = Convert.ToInt32(deleteordernoTextBox.Text);
            //Sell sell = sellDataAccess.GetSellByOrderNo(no);
            //if (sell == null)
            //{
                //MessageBox.Show("Order No not available");
                //ClearFields();
            //}
            //else
            {
                DialogResult result = MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    sellDataAccess = new SellDataAccess();
                    if (sellDataAccess.DeleteSell(Convert.ToInt32(deleteordernoTextBox.Text)))
                    {
                        MessageBox.Show("Order deleted");
                        UpdateGridView();
                        ClearFields();
                    }
                    else
                    {
                        MessageBox.Show("Error in deleting");
                    }
                }

            }
        }

        private void searchboxDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            updateproductnameTextBox.Text = searchboxDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            cartproductnameTextBox.Text = searchboxDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
            cartproductpriceTextBox.Text = searchboxDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            if (productDataAccess.UpdateProductCart((Convert.ToInt32(updateproductquantityTextBox.Text)), updateproductnameTextBox.Text))
            {
                MessageBox.Show("Updated");
                UpdateGridView();
                ClearFields();
            }
            else
            {
                MessageBox.Show("Unable update");
                ClearFields();
            }
        }

        private void cartDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            deleteordernoTextBox.Text = cartDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void paymentButton_Click(object sender, EventArgs e)
        {
            PaymentSystem paymentSystem = new PaymentSystem();
            paymentSystem.Show();
            this.Hide();
        }

        private void searchordernoTextBox_TextChanged(object sender, EventArgs e)
        {
            SellDataAccess sellDataAccess = new SellDataAccess();
            int a = Convert.ToInt32(searchordernoTextBox.Text);
            cartDataGridView.DataSource = sellDataAccess.GetSellsListByOrderNo(a);
        }

        //private void loadButton_Click(object sender, EventArgs e)
        //{
        //    if (productnameTextBox.Text == "")
        //    {
        //        MessageBox.Show("Product Name box can not be empty");
        //    }
        //    else
        //    {
        //        ProductDataAccess productDataAccess = new ProductDataAccess();
        //        string name = productnameTextBox.Text;
        //        Product product = productDataAccess.GetProductListByNames();
        //        if (product == null)
        //        {
        //            MessageBox.Show("Category not available");
        //            ClearFields();
        //        }
        //    }
        //}
    }
}
