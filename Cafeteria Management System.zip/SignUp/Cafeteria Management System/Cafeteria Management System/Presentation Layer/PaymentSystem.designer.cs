﻿
namespace Cafeteria_Management_System.Presentation_Layer
{
    partial class PaymentSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cash = new System.Windows.Forms.Button();
            this.Online = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Cash
            // 
            this.Cash.Location = new System.Drawing.Point(320, 257);
            this.Cash.Name = "Cash";
            this.Cash.Size = new System.Drawing.Size(161, 90);
            this.Cash.TabIndex = 3;
            this.Cash.Text = "Cash Payment";
            this.Cash.UseVisualStyleBackColor = true;
            this.Cash.Click += new System.EventHandler(this.Cash_Click);
            // 
            // Online
            // 
            this.Online.Location = new System.Drawing.Point(320, 103);
            this.Online.Name = "Online";
            this.Online.Size = new System.Drawing.Size(161, 90);
            this.Online.TabIndex = 2;
            this.Online.Text = "Online Payment";
            this.Online.UseVisualStyleBackColor = true;
            this.Online.Click += new System.EventHandler(this.Online_Click);
            // 
            // PaymentSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Cash);
            this.Controls.Add(this.Online);
            this.Name = "PaymentSystem";
            this.Text = "PaymentSystem";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Cash;
        private System.Windows.Forms.Button Online;
    }
}