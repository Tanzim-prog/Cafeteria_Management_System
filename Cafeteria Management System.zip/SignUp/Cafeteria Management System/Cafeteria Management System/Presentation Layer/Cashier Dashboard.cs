﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Cashier_Dashboard : Form
    {
        public Cashier_Dashboard()
        {
            InitializeComponent();
        }

        private void Cashier_Dashboard_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }

        private void inventoryButton_Click(object sender, EventArgs e)
        {
            Cashier_Inventory cashier_Inventory = new Cashier_Inventory();
            cashier_Inventory.Show();
            this.Hide();
        }

        private void cartButton_Click(object sender, EventArgs e)
        {
            Cashier_Cart cashier_Cart = new Cashier_Cart();
            cashier_Cart.Show();
            this.Hide();
        }
    }
}
