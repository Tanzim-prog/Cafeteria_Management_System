﻿using Cafeteria_Management_System.Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Cashier_Inventory : Form
    {
        public Cashier_Inventory()
        {
            InitializeComponent();
        }

        private void Cashier_Inventory_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void Cashier_Inventory_Load(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            productsGridView.DataSource = productDataAccess.GetProducts();
        }

        private void dashboardButton_Click(object sender, EventArgs e)
        {
            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();
        }

        private void searchproductnameTextBox_TextChanged(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            searchproductDataGridView.DataSource = productDataAccess.GetProductListByNames(searchproductnameTextBox.Text);
        }

        private void searchproductnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }
    }
}
