﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Login_Category : Form
    {
        public Login_Category()
        {
            InitializeComponent();
        }

        private void Login_Category_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void managerButton_Click(object sender, EventArgs e)
        {
            Login_Page_Manager login_Page_Manager = new Login_Page_Manager();
            login_Page_Manager.Show();
            this.Hide();
        }

        private void cashierButton_Click(object sender, EventArgs e)
        {
            Login_Page_Cashier login_Page_Cashier = new Login_Page_Cashier();
            login_Page_Cashier.Show();
            this.Hide();
        }

        private void welcomeButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
