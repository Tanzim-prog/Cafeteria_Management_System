﻿using SignUp;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria_Management_System.Data_Access_Layer
{
    class SignUpDataAccess:DataAccess
    {
        public bool SignUp(SignUpData signUpData)
        {
            string sql = "INSERT INTO SignUpData(FullName, UserID, Email, Password, DateOfBirth, Gender, BloodGroup) VALUES('" + signUpData.FullName + "','" + signUpData.UserID + "','" + signUpData.Email + "','" + signUpData.Password + "','" + signUpData.DateOfBirth + "','" + signUpData.Gender + "','" + signUpData.BloodGroup + "')";
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }
        public bool ValidateLogin(string userID, string password)
        {
            string sql = "SELECT * FROM SignUpData WHERE UserID='" + userID + "' AND Password='" + password + "'";
            SqlDataReader reader = this.GetData(sql);
            if (reader.HasRows)
                return true;
            else
                return false;
        }
    }
}
