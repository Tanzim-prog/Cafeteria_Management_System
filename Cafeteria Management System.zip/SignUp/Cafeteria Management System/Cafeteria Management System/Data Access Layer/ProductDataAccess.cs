﻿using Cafeteria_Management_System.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria_Management_System.Data_Access_Layer
{
    class ProductDataAccess:DataAccess
    {
        public List<Product> GetProducts()
        {
            string sql = "SELECT * FROM Products";
            SqlDataReader reader = this.GetData(sql);
            List<Product> products = new List<Product>();

            while(reader.Read())
            {
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                products.Add(product);
            }

            return products;
        }

        public List<Product> GetProductListByNames(string str)
        {
            string sql = "SELECT * FROM Products WHERE ProductName LIKE '"+str+ "%'";
            SqlDataReader reader = this.GetData(sql);
            List<Product> products = new List<Product>();

            while (reader.Read())
            {
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                products.Add(product);
            }

            return products;
        }
        public bool UpdateProductCart(int productQuantity, string productName)
        {
            string sql = "UPDATE Products SET ProductQuantity=" + productQuantity + "WHERE ProductName LIKE '"+ productName +"%'";
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////


        public Product GetProductByID(int productID)
        {
            string sql = "SELECT * FROM Products WHERE ProductID=" + productID;
            SqlDataReader reader = this.GetData(sql);
            if (reader.HasRows)
            {
                reader.Read();
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                return product;
            }
            return null;
        }
        public bool CreateProduct(string productName, double productPrice, int productQuantity, int categoryID)
        {
            string sql = "INSERT INTO Products(ProductName, ProductPrice, ProductQuantity, CategoryID) VALUES('" + productName + "'," + productPrice + "," + productQuantity + "," + categoryID + ")";
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }
        public bool UpdateProduct(int productID, string productName, double productPrice, int productQuantity, int categoryID)
        {
            string sql = "UPDATE Products SET ProductName='" + productName + "', ProductPrice=" + productPrice + ", ProductQuantity=" + productQuantity + ", CategoryID=" + categoryID + " WHERE ProductID=" + productID;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }
        public bool DeleteProduct(int productID)
        {
            string sql = "DELETE FROM Products WHERE ProductID=" + productID;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }
        public bool DeleteProductQuantity(int productQuantity)
        {
            string sql = "DELETE FROM Products WHERE ProductQuantity=" + productQuantity;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }
        public List<Product> GetProductsByCategoryID(int categoryID)
        {
            string sql = "SELECT * FROM Products WHERE CategoryID=" + categoryID;
            SqlDataReader reader = this.GetData(sql);
            List<Product> products = new List<Product>();
            while (reader.Read())
            {
                Product product = new Product();
                product.ProductID = (int)reader["ProductID"];
                product.ProductName = reader["ProductName"].ToString();
                product.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                product.ProductQuantity = (int)reader["ProductQuantity"];
                product.CategoryID = (int)reader["CategoryID"];
                products.Add(product);
            }
            return products;
        }
    }
}
