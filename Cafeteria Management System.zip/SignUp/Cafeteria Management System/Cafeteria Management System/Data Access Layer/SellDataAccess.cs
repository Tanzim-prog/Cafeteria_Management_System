﻿using Cafeteria_Management_System.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria_Management_System.Data_Access_Layer
{
    class SellDataAccess:DataAccess
    {
        public List<Sell> GetSells()
        {
            string sql = "SELECT * FROM Sells";
            SqlDataReader reader = this.GetData(sql);
            List<Sell> sells = new List<Sell>();

            while (reader.Read())
            {
                Sell sell= new Sell();
                sell.OrderNo = (int)reader["OrderNo"];
                sell.ProductName = reader["ProductName"].ToString();
                sell.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                sell.ProductQuantity = (int)reader["ProductQuantity"];
                sell.Total = Convert.ToDouble(reader["Total"]);
                sells.Add(sell);
            }

            return sells;
        }

        public Sell GetSellByOrderNo(int orderNo)
        {
            string sql = "SELECT * FROM Sells WHERE OrderNo=" + orderNo;
            SqlDataReader reader = this.GetData(sql);
            if (reader.HasRows)
            {
                reader.Read();
                Sell sell = new Sell();
                sell.OrderNo = (int)reader["OrderNo"];
                sell.ProductName = reader["ProductName"].ToString();
                sell.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                sell.ProductQuantity = (int)reader["ProductQuantity"];
                sell.Total = (int)reader["Total"];
                return sell;
            }
            return null;
        }

        public Sell GetSellByName(int productName)
        {
            string sql = "SELECT * FROM Sells WHERE ProductName=" + productName;
            SqlDataReader reader = this.GetData(sql);
            if (reader.HasRows)
            {
                reader.Read();
                Sell sell = new Sell();
                sell.OrderNo = (int)reader["OrderNo"];
                sell.ProductName = reader["SellProductName"].ToString();
                sell.ProductPrice = Convert.ToDouble(reader["SellProductPrice"]);
                sell.ProductQuantity = (int)reader["SellProductQuantity"];
                sell.Total = (int)reader["Total"];
                return sell;
            }
            return null;
        }

        public List<Sell> GetSellsListByOrderNo(int i)
        {
            string sql = "SELECT * FROM Sells WHERE OrderNo LIKE '"+ i +"'";
            SqlDataReader reader = this.GetData(sql);
            List<Sell> sells = new List<Sell>();

            while (reader.Read())
            {
                Sell sell = new Sell();
                sell.OrderNo = (int)reader["OrderNo"];
                sell.ProductName = reader["ProductName"].ToString();
                sell.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                sell.ProductQuantity = (int)reader["ProductQuantity"];
                sell.Total = Convert.ToDouble(reader["Total"]);
                sells.Add(sell);
            }

            return sells;
        }

        public bool CreateSell(int orderNo, string productName, double productPrice, int productQuantity, double Total)
        {
            string sql = "INSERT INTO Sells (OrderNo, ProductName, ProductPrice, ProductQuantity, Total) VALUES(" + orderNo + ",'" + productName+"',"+ productPrice + ","+ productQuantity + ","+ Total + ")";
            int result = this.ExecuteQuery(sql);
            if(result>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateSell(int orderNo, string productName, double productPrice, int productQuantity, double Total)
        {
            string sql = "UPDATE Sells SET ProductName='" + productName + "', ProductPrice=" + productPrice + ", ProductQuantity=" + productQuantity + ", Total=" + Total + " WHERE OrderNo=" + orderNo;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteSell(int orderNo)
        {
            string sql = "DELETE FROM Sells WHERE OrderNo LIKE '"+ orderNo + "%'";
            int result = this.ExecuteQuery(sql);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
