﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        private void welcomeButton_Click(object sender, EventArgs e)
        {
            
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string userid = "^([A-Z])-[0-9]{3}$";
            if (Regex.IsMatch(useridTextBox.Text, userid))
            {
            }
            else
            {
                MessageBox.Show("Invalid User ID");
            }

            string password = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, password))
            {
            }
            else
            {
                MessageBox.Show("Password must be minimum 8 keys maximum 20 keys");
            }
        }

        private void useridTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([A-Z]{1})-([0-9]{3})$";
            if (Regex.IsMatch(useridTextBox.Text, pattern))
            {
                errorProvider2.Clear();
            }
            else
            {
                errorProvider2.SetError(this.useridTextBox, "User ID is invalid");
                return;
            }
        }

        private void passwordTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.passwordTextBox, "Password is invalid");
                return;
            }
        }
    }
}
