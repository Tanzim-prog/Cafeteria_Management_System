﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Welcome
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Welcome());
        }
    }
}


/*
private void Cashier_Cart_FormClosing(object sender, FormClosingEventArgs e)
{
    DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
    if (dialogResult == DialogResult.Yes)
    {
        Application.ExitThread();
    }
    else
    {
        e.Cancel = true;
    }
}

private void dashboardButton_Click(object sender, EventArgs e)
{
    Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
    cashier_Dashboard.Show();
    this.Hide();
}

private void Cashier_Cart_Load(object sender, EventArgs e)
{
    ProductDataAccess productDataAccess = new ProductDataAccess();
    cartproductsDataGridView.DataSource = productDataAccess.GetProducts();

    cartproductsDataGridView.SelectedRows[0].Cells[0].Value = false;
}

private void searchproductnameTextBox_TextChanged(object sender, EventArgs e)
{
    ProductDataAccess productDataAccess = new ProductDataAccess();
    cartproductsDataGridView.DataSource = productDataAccess.GetProductListByNames(searchproductnameTextBox.Text);
}

void UpdateGridView()
{
    SellDataAccess sellDataAccess = new SellDataAccess();
    checkoutDataGridView.DataSource = sellDataAccess.GetSells();
}

void ClearFields()
{
    checkoutproductnameTextBox.Text = string.Empty;
    checkoutproductidTextBox.Text = string.Empty;
    checkoutproductpriceTextBox.Text = string.Empty;
    checkoutproductquantityTextBox.Text = string.Empty;
    checkouttotalTextBox.Text = string.Empty;
}

private void addButton_Click(object sender, EventArgs e)
{
    SellDataAccess sellDataAccess = new SellDataAccess();
    if (sellDataAccess.CreateSell(checkoutproductnameTextBox.Text, Convert.ToInt32(checkoutproductidTextBox.Text), Convert.ToDouble(checkoutproductpriceTextBox.Text), Convert.ToInt32(checkoutproductquantityTextBox.Text), Convert.ToDouble(checkouttotalTextBox.Text)))
    {
        MessageBox.Show("Added to Cart");
        UpdateGridView();
        ClearFields();
    }
    else
    {
        MessageBox.Show("Unable to add");
        ClearFields();
    }
}
    }*/
