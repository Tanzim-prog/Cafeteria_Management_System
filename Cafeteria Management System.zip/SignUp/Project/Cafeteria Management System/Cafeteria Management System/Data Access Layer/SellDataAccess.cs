﻿using Cafeteria_Management_System.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria_Management_System.Data_Access_Layer
{
    class SellDataAccess:DataAccess
    {
        public List<Sell> GetSells()
        {
            string sql = "SELECT * FROM Sell";
            SqlDataReader reader = this.GetData(sql);
            List<Sell> sells = new List<Sell>();

            while (reader.Read())
            {
                Sell sell= new Sell();
                sell.ProductID = (int)reader["ProductID"];
                sell.ProductName = reader["ProductName"].ToString();
                sell.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
                sell.ProductQuantity = (int)reader["ProductQuantity"];
                sell.Total = Convert.ToDouble(reader["Total"]);
                sells.Add(sell);
            }

            return sells;
        }

        //public Product GetSellById(int productId)
        //{
        //    string sql = "SELECT * FROM Sell WHERE ProductId=" + productId;
        //    SqlDataReader reader = this.GetData(sql);
        //    if (reader.HasRows)
        //    {
        //        reader.Read();
        //        Sell sell = new Sell();
        //        sell.ProductID = (int)reader["ProductId"];
        //        sell.ProductName = reader["ProductName"].ToString();
        //        sell.ProductPrice = Convert.ToDouble(reader["ProductPrice"]);
        //        sell.ProductQuantity = (int)reader["ProductQuantity"];
        //        sell.Total = (int)reader["Total"];
        //        return sell;
        //    }
        //    return null;
        //}

        public bool CreateSell(string productName, int productID, double productPrice, int productQuantity, double Total)
        {
            string sql = "INSERT INTO SELL (ProductName, ProductID, ProductPrice, ProductQuantity, Total) VALUES('"+productName+"',"+ productID + ","+ productPrice + ","+ productQuantity + ","+ Total + ")";
            int result = this.ExecuteQuery(sql);
            if(result>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool UpdateSell(string productName, int productID, double productPrice, int productQuantity, double Total)
        {
            string sql = "UPDATE SELL SET ProductName='" + productName + "', ProductPrice=" + productPrice + ", ProductQuantity=" + productQuantity + ", Total=" + Total + " WHERE ProductID=" + productID;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteSell(int productID)
        {
            string sql = "DELETE FROM SELL WHERE ProductID=" + productID;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
