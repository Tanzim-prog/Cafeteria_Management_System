﻿using SignUp;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cafeteria_Management_System.Data_Access_Layer
{
    class SignUpDataAccess : DataAccess
    {
        public string user_name, user_password;
       
        public bool SignUp(SignUpData signUpData)
        {
            string sql = "INSERT INTO SignUpData(FullName, UserID, Email, Password, DateOfBirth, Gender, BloodGroup) VALUES('" + signUpData.FullName + "','" + signUpData.UserID + "','" + signUpData.Email + "','" + signUpData.Password + "','" + signUpData.DateOfBirth + "','" + signUpData.Gender + "','" + signUpData.BloodGroup + "')";
            user_name = signUpData.UserID;
             user_password = signUpData.Password;
            int result = this.ExecuteQuery(sql);
            if (result > 0)
                return true;
            else
                return false;
        }

        public string return_user_name ()
            {
            

            return user_name;
            

            }
        public string return_user_password()
        {


            return user_password;


        }

        public bool ValidateLogin(string userID, string password)
        {
            string sql = "SELECT * FROM SignUpData WHERE UserID='" + userID + "' AND Password='" + password + "'";
            SqlDataReader reader = this.GetData(sql);
            if (reader.HasRows)
                return true;
            else
                return false;
        }
    }
}
