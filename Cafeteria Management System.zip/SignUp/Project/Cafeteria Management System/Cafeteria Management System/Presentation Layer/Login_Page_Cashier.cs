﻿using Cafeteria_Management_System.Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Login_Page_Cashier : Form
    {

        public string u_id, u_pass;

        public Login_Page_Cashier()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Login_Page_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string userid = "^([A-Z])-[0-9]{3}$";
            DataAccess a = new DataAccess();
            if (Regex.IsMatch(useridTextBox.Text, userid))
            {

                this.u_id = useridTextBox.Text;


               // String Username = "E-001", Password = "password";
               // double Total_paying_amount = 1234.00, Earn = 567.00;
               
                //string sql = "INSERT INTO Payment(Username) VALUES('" + useridTextBox.Text + "')";
                //a.ExecuteQuery(sql);
           
            
            }
            else
            {
                MessageBox.Show("Invalid User ID");
            }

            string password = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, password))
            {
                this.u_pass = passwordTextBox.Text;
                string sql1 = "INSERT INTO Payment(Username,Password) VALUES('" + u_id + "','" + u_pass + "')";
                //string sql = "INSERT INTO Payment(Username,Password,Total_paying_amount,Earn) VALUES('" + Username + "','" + Password + "','" + Total_paying_amount + "','" + Earn + "')";

                a.ExecuteQuery(sql1);
            }
            else
            {
                MessageBox.Show("Password must be minimum 8 keys maximum 20 keys");
            }

            SignUpDataAccess signUpDataAccess = new SignUpDataAccess();
            if (signUpDataAccess.ValidateLogin(useridTextBox.Text, passwordTextBox.Text))
            {
                Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
                cashier_Dashboard.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect username or password");
            }
        }

        private void useridTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([A-Z]{1})-([0-9]{3})$";
            if (Regex.IsMatch(useridTextBox.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.useridTextBox, "User ID is invalid");
                return;
            }
        }

        private void passwordTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, pattern))
            {
                errorProvider2.Clear();
            }
            else
            {
                errorProvider2.SetError(this.passwordTextBox, "Password is invalid");
                return;
            }
        }

        private void welcomeButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }

        private void useridTextBox_TextChanged(object sender, EventArgs e)
        {
            //string pattern = "^([E]{1})-([0-9]{3})$";
            //if (Regex.IsMatch(passwordTextBox.Text, pattern))
            //{
            //    Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            //    cashier_Dashboard.Show();
            //    this.Hide();
            //}
            //else
            //{

            //}
        }
    }
}
