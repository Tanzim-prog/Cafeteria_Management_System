﻿
namespace Cafeteria_Management_System.Presentation_Layer
{
    partial class Cashier_Cart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.searchboxDataGridView = new System.Windows.Forms.DataGridView();
            this.searchproductnameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.paymentButton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.carttotalTextBox = new System.Windows.Forms.TextBox();
            this.cartproductidTextBox = new System.Windows.Forms.TextBox();
            this.cartproductpriceTextBox = new System.Windows.Forms.TextBox();
            this.cartproductquantityTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.cartDataGridView = new System.Windows.Forms.DataGridView();
            this.cartproductnameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dashboardButton = new System.Windows.Forms.Button();
            this.logoutButton = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchboxDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cartDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.searchboxDataGridView);
            this.groupBox2.Controls.Add(this.searchproductnameTextBox);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(796, 218);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search Box";
            // 
            // searchboxDataGridView
            // 
            this.searchboxDataGridView.AllowUserToAddRows = false;
            this.searchboxDataGridView.AllowUserToDeleteRows = false;
            this.searchboxDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.searchboxDataGridView.Location = new System.Drawing.Point(252, 24);
            this.searchboxDataGridView.Name = "searchboxDataGridView";
            this.searchboxDataGridView.ReadOnly = true;
            this.searchboxDataGridView.Size = new System.Drawing.Size(526, 176);
            this.searchboxDataGridView.TabIndex = 4;
            // 
            // searchproductnameTextBox
            // 
            this.searchproductnameTextBox.Location = new System.Drawing.Point(73, 116);
            this.searchproductnameTextBox.Name = "searchproductnameTextBox";
            this.searchproductnameTextBox.Size = new System.Drawing.Size(151, 25);
            this.searchproductnameTextBox.TabIndex = 2;
            this.searchproductnameTextBox.TextChanged += new System.EventHandler(this.searchproductnameTextBox_TextChanged);
            this.searchproductnameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.searchproductnameTextBox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(69, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search Product Name";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.paymentButton);
            this.groupBox1.Controls.Add(this.addButton);
            this.groupBox1.Controls.Add(this.carttotalTextBox);
            this.groupBox1.Controls.Add(this.cartproductidTextBox);
            this.groupBox1.Controls.Add(this.cartproductpriceTextBox);
            this.groupBox1.Controls.Add(this.cartproductquantityTextBox);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cartDataGridView);
            this.groupBox1.Controls.Add(this.cartproductnameTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 236);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(923, 454);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Cart";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // paymentButton
            // 
            this.paymentButton.Location = new System.Drawing.Point(149, 349);
            this.paymentButton.Name = "paymentButton";
            this.paymentButton.Size = new System.Drawing.Size(75, 36);
            this.paymentButton.TabIndex = 14;
            this.paymentButton.Text = "Payment";
            this.paymentButton.UseVisualStyleBackColor = true;
            this.paymentButton.Click += new System.EventHandler(this.paymentButton_Click);
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(53, 349);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 36);
            this.addButton.TabIndex = 13;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // carttotalTextBox
            // 
            this.carttotalTextBox.Location = new System.Drawing.Point(139, 284);
            this.carttotalTextBox.Name = "carttotalTextBox";
            this.carttotalTextBox.Size = new System.Drawing.Size(151, 25);
            this.carttotalTextBox.TabIndex = 12;
            this.carttotalTextBox.TextChanged += new System.EventHandler(this.carttotalTextBox_TextChanged);
            this.carttotalTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.carttotalTextBox_KeyPress);
            // 
            // cartproductidTextBox
            // 
            this.cartproductidTextBox.Location = new System.Drawing.Point(139, 161);
            this.cartproductidTextBox.Name = "cartproductidTextBox";
            this.cartproductidTextBox.Size = new System.Drawing.Size(151, 25);
            this.cartproductidTextBox.TabIndex = 11;
            this.cartproductidTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cartproductidTextBox_KeyPress);
            // 
            // cartproductpriceTextBox
            // 
            this.cartproductpriceTextBox.Location = new System.Drawing.Point(139, 203);
            this.cartproductpriceTextBox.Name = "cartproductpriceTextBox";
            this.cartproductpriceTextBox.Size = new System.Drawing.Size(151, 25);
            this.cartproductpriceTextBox.TabIndex = 10;
            this.cartproductpriceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cartproductpriceTextBox_KeyPress);
            // 
            // cartproductquantityTextBox
            // 
            this.cartproductquantityTextBox.Location = new System.Drawing.Point(139, 243);
            this.cartproductquantityTextBox.Name = "cartproductquantityTextBox";
            this.cartproductquantityTextBox.Size = new System.Drawing.Size(151, 25);
            this.cartproductquantityTextBox.TabIndex = 9;
            this.cartproductquantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cartproductquantityTextBox_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = "Product ID";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 19);
            this.label5.TabIndex = 7;
            this.label5.Text = "Product Price";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Product Quantity";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 284);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Total";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // cartDataGridView
            // 
            this.cartDataGridView.AllowUserToAddRows = false;
            this.cartDataGridView.AllowUserToDeleteRows = false;
            this.cartDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cartDataGridView.Location = new System.Drawing.Point(314, 24);
            this.cartDataGridView.Name = "cartDataGridView";
            this.cartDataGridView.ReadOnly = true;
            this.cartDataGridView.Size = new System.Drawing.Size(591, 419);
            this.cartDataGridView.TabIndex = 4;
            // 
            // cartproductnameTextBox
            // 
            this.cartproductnameTextBox.Location = new System.Drawing.Point(139, 119);
            this.cartproductnameTextBox.Name = "cartproductnameTextBox";
            this.cartproductnameTextBox.Size = new System.Drawing.Size(151, 25);
            this.cartproductnameTextBox.TabIndex = 2;
            this.cartproductnameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cartproductnameTextBox_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Product Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // dashboardButton
            // 
            this.dashboardButton.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dashboardButton.Location = new System.Drawing.Point(824, 36);
            this.dashboardButton.Name = "dashboardButton";
            this.dashboardButton.Size = new System.Drawing.Size(93, 45);
            this.dashboardButton.TabIndex = 8;
            this.dashboardButton.Text = "Dashboard";
            this.dashboardButton.UseVisualStyleBackColor = true;
            this.dashboardButton.Click += new System.EventHandler(this.dashboardButton_Click);
            // 
            // logoutButton
            // 
            this.logoutButton.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutButton.Location = new System.Drawing.Point(824, 108);
            this.logoutButton.Name = "logoutButton";
            this.logoutButton.Size = new System.Drawing.Size(93, 45);
            this.logoutButton.TabIndex = 9;
            this.logoutButton.Text = "LogOut";
            this.logoutButton.UseVisualStyleBackColor = true;
            this.logoutButton.Click += new System.EventHandler(this.logoutButton_Click);
            // 
            // Cashier_Cart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 702);
            this.Controls.Add(this.logoutButton);
            this.Controls.Add(this.dashboardButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Name = "Cashier_Cart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cashier_Cart";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Cashier_Cart_FormClosing);
            this.Load += new System.EventHandler(this.Cashier_Cart_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchboxDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cartDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView searchboxDataGridView;
        private System.Windows.Forms.TextBox searchproductnameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox carttotalTextBox;
        private System.Windows.Forms.TextBox cartproductidTextBox;
        private System.Windows.Forms.TextBox cartproductpriceTextBox;
        private System.Windows.Forms.TextBox cartproductquantityTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView cartDataGridView;
        private System.Windows.Forms.TextBox cartproductnameTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button paymentButton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Button dashboardButton;
        private System.Windows.Forms.Button logoutButton;
    }
}