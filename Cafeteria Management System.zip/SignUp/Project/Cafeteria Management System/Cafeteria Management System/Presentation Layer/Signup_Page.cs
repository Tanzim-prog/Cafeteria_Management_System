﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Cafeteria_Management_System.Data_Access_Layer;
using Cafeteria_Management_System.Presentation_Layer;
using SignUp;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Signup_Page : Form
    {
        public Signup_Page()
        {
            InitializeComponent();
        }

        private void Signup_Page_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void OthersRadioButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void termsCheckBox_Click(object sender, EventArgs e)
        {
            if(termsCheckBox.Checked==true)
            {
                submitButton.Enabled = true;
            }
            else
            {
                submitButton.Enabled = false;
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            if (fullnameTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Full Name box");
            }


            string userid = "^([A-Z])-[0-9]{3}$";
            if (Regex.IsMatch(useridTextBox.Text, userid))
            {
            }
            else
            {
                MessageBox.Show("Invalid User ID");
            }
            string email = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(emailTextBox.Text, email))
            {
            }
            else
            {
                MessageBox.Show("Invalid Email Address");
            }
            string password = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, password))
            {
            }
            else
            {
                MessageBox.Show("Password must be minimum 8 keys maximum 20 keys");
            }

            if (confirmpasswordTextBox.Text != passwordTextBox.Text)
            {
                MessageBox.Show("Confrim Password doesn't match with Password");
            }
            else if (maleRadioButton.Checked == false && femaleRadioButton.Checked == false && othersRadioButton.Checked == false)
            {
                MessageBox.Show("You must select Gender");
            }
            else
            {
                SignUpData signUpData = new SignUpData();
                signUpData.FullName = fullnameTextBox.Text;
                signUpData.UserID = useridTextBox.Text;
                signUpData.Password = passwordTextBox.Text;
                signUpData.Email = emailTextBox.Text;
                signUpData.DateOfBirth = dateofbirthDateTime.Text;
                if (maleRadioButton.Checked)
                {
                    signUpData.Gender = "Male";
                }
                else if (femaleRadioButton.Checked)
                {
                    signUpData.Gender = "Female";
                }
                else
                {
                    signUpData.Gender = "Others";
                }
                signUpData.BloodGroup = bloodgroupComboBox.Text;

                SignUpDataAccess signUpDataAccess = new SignUpDataAccess();
                if (signUpDataAccess.SignUp(signUpData))
                { 
                    MessageBox.Show("User added");
                    Login_Page_Cashier login_Page = new Login_Page_Cashier();
                    login_Page.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Error in User adding");
                }
            }

        }

        private void fullnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void useridTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsDigit(e.KeyChar)) &&  e.KeyChar !=45)
            {
                e.Handled = true;
            }
        }

        private void emailTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetterOrDigit(e.KeyChar) && (!char.IsControl(e.KeyChar)) && e.KeyChar!=46 && e.KeyChar!=64)
            {
                e.Handled = true;
            }
        }

        private void emailTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[a-zA-Z]{2,9})$";
            if (Regex.IsMatch(emailTextBox.Text,pattern))
            {
                errorProvider3.Clear();
            }
            else
            {
                errorProvider3.SetError(this.emailTextBox, "Email address is invalid");
                return;
            }
        }

        private void useridTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([A-Z]{1})-([0-9]{3})$";
            if (Regex.IsMatch(useridTextBox.Text, pattern))
            {
                errorProvider2.Clear();
            }
            else
            {
                errorProvider2.SetError(this.useridTextBox, "User ID is invalid");
                return;
            }
        }

        private void passwordTextBox_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]{8,20})$";
            if (Regex.IsMatch(passwordTextBox.Text, pattern))
            {
                errorProvider1.Clear();
            }
            else
            {
                errorProvider1.SetError(this.passwordTextBox, "Password is invalid");
                return;
            }
        }

        private void confirmpasswordTextBox_Leave(object sender, EventArgs e)
        {
            if (confirmpasswordTextBox.Text == passwordTextBox.Text)
            {
                errorProvider4.Clear();
            }
            else
            {
                errorProvider4.SetError(this.confirmpasswordTextBox, "Confrim Password doesn't match with Password");
                return;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void welcomeButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }
    }
}