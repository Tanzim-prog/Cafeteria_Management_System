﻿using Cafeteria_Management_System.Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class Cashier_Cart : Form
    {
        public double total_amount;
       public  List<double> amount_list = new List<double>();
        DataAccess a = new DataAccess();
        public Cashier_Cart()
        {
            InitializeComponent();
        }

        private void Cashier_Cart_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Close the application?", "Exit", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Application.ExitThread();
            }
            else
            {
                e.Cancel = true;
            }
        }

        private void dashboardButton_Click(object sender, EventArgs e)
        {
            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();
        }

        private void Cashier_Cart_Load(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            searchboxDataGridView.DataSource = productDataAccess.GetProducts();
        }

        private void searchproductnameTextBox_TextChanged(object sender, EventArgs e)
        {
            ProductDataAccess productDataAccess = new ProductDataAccess();
            searchboxDataGridView.DataSource = productDataAccess.GetProductListByNames(searchproductnameTextBox.Text);
        }

        void UpdateGridView()
        {
            SellDataAccess sellDataAccess = new SellDataAccess();
            cartDataGridView.DataSource = sellDataAccess.GetSells();
        }

        void ClearFields()
        {
            cartproductnameTextBox.Text = string.Empty;
            cartproductidTextBox.Text = string.Empty;
            cartproductpriceTextBox.Text = string.Empty;
            cartproductquantityTextBox.Text = string.Empty;
            carttotalTextBox.Text = string.Empty;
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if (cartproductnameTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Product Name box");
            }
            else if (cartproductidTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Product ID box");
            }
            else if (cartproductpriceTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Product Price box");
            }
            else if (cartproductquantityTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Product Quantity box");
            }
            else if (carttotalTextBox.Text == "")
            {
                MessageBox.Show("You must fill up the Total box");
            }
            else
            {
                SellDataAccess sellDataAccess = new SellDataAccess();

               /* this.total_amount = Convert.ToDouble(carttotalTextBox.Text);
                Console.WriteLine(total_amount);

                this.amount_list.Add(total_amount);*/


                if (sellDataAccess.CreateSell(cartproductnameTextBox.Text, Convert.ToInt32(cartproductidTextBox.Text), Convert.ToDouble(cartproductpriceTextBox.Text), Convert.ToInt32(cartproductquantityTextBox.Text), Convert.ToDouble(carttotalTextBox.Text)))
                {
                    MessageBox.Show("Added to Cart");
                    UpdateGridView();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to add");
                    ClearFields();
                }
            }
        }

        public List<double> ReturnAmountLlist()
        {
            return this.amount_list;
        }

        private void cartproductnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void cartproductidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void cartproductpriceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void cartproductquantityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void carttotalTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && (!char.IsDigit(e.KeyChar)) && e.KeyChar != 45)
            {
                e.Handled = true;
            }
        }

        private void searchproductnameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            Welcome_Page welcome_Page = new Welcome_Page();
            welcome_Page.Show();
            this.Hide();
        }

        private void paymentButton_Click(object sender, EventArgs e)
        {

            /*

            SqlCommand command;

            string sql = "SELECT id FROM Payment";
            SqlDataReader reader;
            command = new SqlCommand(sql);
            reader = command.ExecuteReader();
            int i = 0;
            List<int> IDs = new List<int>();
            while (reader.Read())
            {

                IDs.Add(reader.GetInt32(i));
                i = i + 1;
            }
          
            */
         







            string sql2 = "INSERT INTO Payment(Total_paying_amount) VALUES('" + this.total_amount + "')";
            a.ExecuteQuery(sql2);


            PaymentSystem PaymentSystem = new PaymentSystem();
            PaymentSystem.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void carttotalTextBox_TextChanged(object sender, EventArgs e)
        {
            this.total_amount = Convert.ToDouble(carttotalTextBox.Text);
           
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
