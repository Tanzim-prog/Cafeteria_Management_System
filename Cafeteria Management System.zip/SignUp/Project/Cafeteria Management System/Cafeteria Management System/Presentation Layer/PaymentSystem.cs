﻿using Cafeteria_Management_System.Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class PaymentSystem : Form
    {
        public List<double> TotalList = new List<double>();
        //Cashier_Cart Cashier_Cart = new Cashier_Cart();
        public PaymentSystem()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
     

        private void Online_Click(object sender, EventArgs e)
        {
            //online
            OnlinePaymentMethood OnlinePaymentMethood = new OnlinePaymentMethood();
            OnlinePaymentMethood.Show();
            this.Hide();

        }

        private void Cash_Click(object sender, EventArgs e)
        {
            //cash

            


            // UserDataAccess userDataAccess = new UserDataAccess();
           

            
          // TotalList = Cashier_Cart.ReturnAmountLlist();





            String Username = "E-001", Password = "password";
            double Total_paying_amount = 1234.00, Earn = 10.00;
            DataAccess a = new DataAccess();
            string sql = "INSERT INTO Payment(Earn) VALUES('" + Earn + "')";
            a.ExecuteQuery(sql);
            MessageBox.Show("Your cash payment has been successfully done ");

            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();
        }
    }
}
