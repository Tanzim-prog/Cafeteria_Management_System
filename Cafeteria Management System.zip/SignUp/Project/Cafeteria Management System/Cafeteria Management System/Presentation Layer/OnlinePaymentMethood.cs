﻿using Cafeteria_Management_System.Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cafeteria_Management_System.Presentation_Layer
{
    public partial class OnlinePaymentMethood : Form
    {
        public OnlinePaymentMethood()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Bikash_Click(object sender, EventArgs e)
        {

            //bkash

            //UserDataAccess userDataAccess = new UserDataAccess();
            DataAccess a = new DataAccess();

            String Username = "bkash", Password = "123";
            double Total_paying_amount = 1234.00, Earn = 10.00;
            string sql = "INSERT INTO Payment(Earn) VALUES('" + Earn + "')";
            a.ExecuteQuery(sql);
            MessageBox.Show("Your  Online payment through Bkash  has been successfully done ");
            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();
        }

        private void Nogod_Click(object sender, EventArgs e)
        {
            //nogod

           // UserDataAccess userDataAccess = new UserDataAccess();
            DataAccess a = new DataAccess();

            String Username = "nogod", Password = "123";
            double Total_paying_amount = 1234.00, Earn = 12.00;
            string sql = "INSERT INTO Payment(Earn) VALUES('" + Earn + "')";
            a.ExecuteQuery(sql);
            MessageBox.Show("Your  Online payment   through Nogod  has been successfully done ");

            Cashier_Dashboard cashier_Dashboard = new Cashier_Dashboard();
            cashier_Dashboard.Show();
            this.Hide();

        }
    }
}
